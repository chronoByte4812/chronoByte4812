import { Server } from '../../../library/Minecraft.js';
import { hasitem, tellrawStaff } from '../../../library/utils/prototype.js';
import { scoreTest } from '../../../library/utils/score_testing.js';
import { obj } from '../staff/gui.js';
const registerInformation = {
    cancelMessage: true,
    name: 'sell',
    staff: 'false',
    description: 'Sell Raw Materials for money',
    usage: '[ iron_ingot | gold_ingot | emerald | diamond | coal | netherite{_ingot/_scrap} | redstone ] [ amount ]',
    example: [
        'sell netherite_scrap 22'
    ]
};
Server.command.register(registerInformation, (chatmsg, args) => {
    try {
        const { sender } = chatmsg;
        const name = sender.getName();
        const SellableItems = {
            'coal': 5,
            'quartz': 8,
            'copper_ingot': 10,
            'iron_ingot': 10,
            'redstone': 15,
            'gold_ingot': 25,
            'diamond': 140,
            'emerald': 150,
            'netherite_scrap': 175,
            'netherite_ingot': 300,
        };
        
        const usage = `§6UAC.sell [item] [amount]`;
        const allitems = `§6coal, copper_ingot, quartz, iron_ingot, redstone, gold_ingot, diamond, emerald, netherite_scrap, netherite_ingot`;
        let icmtoggle = obj('ICM').dummies.get('icmtoggledummy');
        if (icmtoggle === 0 && !sender.hasTag('staffstatus')) return sender.tellraw(`§¶§cUAC ► §c§lThe Realm Owner currently has Player Commands Disabled`);
        if (!args[0]) { return sender.tellraw(`§¶§cUAC ► §cItem not specified. ${usage}`) }
        if (!args[1]) { return sender.tellraw(`§¶§cUAC ► §cAmount not specified. ${usage}`) }

        let item = args[0];
        let amount = parseInt(args[1]);

        if (item in SellableItems) {
            if (hasitem(sender, `minecraft:${item}`) >= amount) {
                let price = 0;
                price = SellableItems[item];
                let cost = (price * amount);
                sender.runCommand(`scoreboard players add @s money ${cost}`);
                sender.runCommand(`clear @s ${item} 0 ${amount}`);
                sender.tellraw(`§¶§cUAC ► §bSold! You now have §c${scoreTest(sender, 'money')}$. §6Item §7: §c${item} §6Amount §7: §c${amount} §6Total Profit §7: §c${cost} §6 Sell Price Per Item §7: §c${price}`);
                tellrawStaff(`§¶§cUAC STAFF STAFF ► §d${name} §bHas sold §c${amount} of §c${item}(s)`);
            }
            else {
                return sender.tellraw(`§¶§cUAC ► §cYou do not have enough of that item`);
            }
        }
        else {
            return sender.tellraw(`§¶§cUAC ► §cInvalid Item. §bItems ${allitems}`);
        }
    }
    catch (error) { console.warn(error, error.stack); }
});
