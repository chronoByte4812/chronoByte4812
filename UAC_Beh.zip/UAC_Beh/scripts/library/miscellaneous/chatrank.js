import { Server } from "../build/classes/serverBuilder.js";

/**
 * @param {import ('@minecraft/server').ChatSendBeforeEvent} chatmsg 
 */
export function displayRank(chatmsg) {
    const allRanks = chatmsg.sender.getTags().filter((tag) => tag.match(/(?<=\$\(chatrank:).*?(?=\))/g))
    chatmsg.cancel = true;
    if (!allRanks)
        return Server.broadcast(`[§bMember§f] §7${chatmsg.sender.nameTag}: §f${chatmsg.message}`);
    Server.broadcast(`[${allRanks.join(', ').trim()}] §7${chatmsg.sender.nameTag}: §f${chatmsg.message}`);
}
;
