import { ObjectiveSortOrder, ScoreboardIdentityType, ScoreboardObjective, system, world } from "@minecraft/server";


function scoreTest(target, objective) {
    try {
        const oB = world.scoreboard.getObjective(objective)
        if (!oB) world.scoreboard.addObjective(objective)
        if (typeof target == 'string') return oB?.getScores().find(pT => pT.displayName == target)?.score
        return oB?.getScore(target) || 0;
    } catch (error) {
        let na = 0;
        // console.warn(error, error.stack);
        return na;
    }
}
/*
function scoreTest(target, objective) {
    try {
        return world.scoreboard.getObjective(objective).getScore(typeof target === 'string' ? oB.getParticipants().find(pT => pT.displayName == target) : target.scoreboardIdentity)
    } catch {
        return NaN
    }
}*/
/**
 * 
 * @param {import('@minecraft/server').Player} target 
 * @param {String} objective 
 * @param {Number} amount 
 * @param {Boolean} add 
 */
function setScore(target, objective, amount, add = false) {
    return system.run(() => {
        try {
            let scoreObj = world.scoreboard.getObjective(objective);

            if (!scoreObj) {
                world.scoreboard.addObjective(objective, objective);
                scoreObj = world.scoreboard.getObjective(objective);
            };

            const participant = typeof target === "string" ? scoreObj.getParticipants().find(p => p.displayName === target) : target.scoreboardIdentity;

            if (!participant)
                return NaN;

            const current = add ? scoreObj.getScore(participant) ?? 0 : 0;
            const newScore = current + amount;
            scoreObj.setScore(participant, newScore);
            return newScore;

        } catch (e) {
            // console.warn(`Error setting score for ${target}: ${e}\n${e.stack}`);
            return NaN;
        }
    });
}

export { scoreTest, setScore };