import { Dimension, system, world } from "@minecraft/server";

/**
 * @type {import('@minecraft/server').Dimension}
 */
let overworld;

system.run(() => {
    overworld = world.getDimension('overworld');
})
// kept for compability - too lazy to change everything on scoreboard.js
async function asyncExecCmd(command, source = overworld) {
    return source.runCommand(command)
};

export {
    overworld,
    asyncExecCmd
}