# Quick dev API documentation for UAC scripting

## To add a new module to UAC gui:

**moduleDefs_prots**
```js
const moduleDefs_prots = [
    {
        mname: 'Display name',
        obj: ['DNM', 'dnmtoggle'],
        name: 'ndmoggledummy',
        toggle: ['§cOFF', '§aON'],
        require: 'has_xx'
    }
    // ... other module objects
]
```

*In the function you want to condition execution:*

**newModule.js:**
```js
/** @type {typeof scoreboard.objective.for} */
const obj = scoreboard.objective.for.bind(scoreboard.objective);
let DNMtoggle = obj('DNM').dummies.get('DNMtoggledummy');

if (DNMtoggle === 0 && !sender.hasTag('staffstatus')) return sender.tellraw(`§¶§cUAC ► §c§lThe Realm Owner currently has Player Commands Disabled`);
// any code below here will only work if the DNMtoggle module is toggled on from the GUI
```

## To add a new command to the system

```js
import { Server } from '../../../library/Minecraft.js';
import scoreboard from "../../../library/scoreboard.js"
import { scoreTest } from '../../index.js';
/** @type {typeof scoreboard.objective.for} */
const obj = scoreboard.objective.for.bind(scoreboard.objective);

Server.command.register(registerInformation, (chatmsg, args) => {
    const { sender } = chatmsg, { location: { x, y, z } } = sender
    let DNMtoggle = obj('DNM').dummies.get('DNMtoggledummy');

    if (DNMtoggle === 0 && !sender.hasTag('staffstatus')) return sender.tellraw(`§¶§cUAC ► §c§lThe Realm Owner currently has Player Commands Disabled`);

    sender.tellraw('Hey! You\'ve just run the test command successfully!');
    
// any code below here will be executed upon the command being used.

});
```